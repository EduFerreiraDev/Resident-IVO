
#version 330 core

out vec4 cor;

uniform vec3 corObjeto;

void main()
{
    cor = vec4(corObjeto, 1.0);
}
